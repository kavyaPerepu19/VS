
import { Route, Routes } from 'react-router-dom';
import './App.css';
import PageNotFound from './components/PageNotFound';
import House from './components/House';
import Header from './components/Header';
import ListAHouse from './components/ListAHouse';
import Login from './components/Login';
import SearchHouse from './components/SearchHouse';
import SignUp from './components/SignUp';
import Home from './components/Home';
import Enquiries from './components/Enquiries';
import SearchFilter from './components/SearchFilter';
import SearchResults from './components/SearchResults';

function App() {
  return (
    <div className="App">
      <Header/>
      <Routes>
        <Route path='/' element={<Home/>}></Route>
        <Route path="*" element={<PageNotFound/>}></Route>
        <Route path='/house/:id' element={<House/>}/>
        <Route path='/listahouse' element={<ListAHouse/>}></Route>
        <Route path='/login' element={<Login/>}></Route>
        <Route path='/signup' element={<SignUp/>}/>
        <Route path='/searchhouse/:id' element={<SearchHouse/>}/> 
        <Route path='/enquiries' element={<Enquiries/>}/>
        <Route path='/search' element={<SearchFilter/>}/>
        <Route path='/searchresults/:locality/:bhk' element={<SearchResults/>}/>
        {/* <Route path='/enquiry' element={<Enquiry></Enquiry>}/> */}
      </Routes>
    </div>
  );
}

export default App;

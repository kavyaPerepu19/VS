const PageNotFound = () =>{
    return (
        <div>
            <h1 className="text-center"> Sorry,we could not find the page that you were looking for.</h1>
            
        </div>
    );
}
export default PageNotFound;